<?php

return [

    'label' => 'Language',

    'plural_label' => 'Languages',

    'table' => [
        'name' => [
            'label' => 'Name',
        ],
        'code' => [
            'label' => 'Code',
        ],
        'default' => [
            'label' => 'Default',
        ],
    ],

    'form' => [
        'name' => [
            'label' => 'Name',
        ],
        'code' => [
            'label' => 'Code',
        ],
        'default' => [
            'label' => 'Default',
        ],
    ],

];
