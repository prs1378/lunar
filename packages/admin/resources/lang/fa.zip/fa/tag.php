<?php

return [

    'label' => 'Tag',

    'plural_label' => 'Tags',

    'table' => [
        'value' => [
            'label' => 'Value',
        ],
    ],

    'form' => [
        'value' => [
            'label' => 'Value',
        ],
    ],

];
