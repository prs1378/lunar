<?php

return [

    'sections' => [
        'catalog' => 'Catalog',
        'sales' => 'Sales',
        'reports' => 'Reports',
        'settings' => 'Settings',
    ],

];
