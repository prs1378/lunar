<?php

return [

    'label' => 'Tax Class',

    'plural_label' => 'Tax Classes',

    'table' => [
        'name' => [
            'label' => 'Name',
        ],
        'default' => [
            'label' => 'Default',
        ],
    ],

    'form' => [
        'name' => [
            'label' => 'Name',
        ],
        'default' => [
            'label' => 'Default',
        ],
    ],

];
